This file is used in the exercise for Manage leads with Dynamics 365 Sales. 
https://docs.microsoft.com/learn/modules/manage-leads-dynamics-365-sales/5-working-with-leads
