# Inventory Management Demo Web API #

Inventory Management Web API demo


## Prerequisites ##

* Visual Studio: [Download][vs download]


[vs download]: https://visualstudio.microsoft.com/downloads/?WT.mc_id=github-0000-juyoo
